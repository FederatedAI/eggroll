from time import sleep

if __name__== '__main__':
    while True:
        print("ok")
        sleep(5)